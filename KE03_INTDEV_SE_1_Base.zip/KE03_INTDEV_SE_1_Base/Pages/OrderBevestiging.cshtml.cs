using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KE03_INTDEV_SE_1_Base.Pages
{
    public class OrderBevestigingModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
